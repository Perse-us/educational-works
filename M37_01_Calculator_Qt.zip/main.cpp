#include <QApplication>
#include "ui_calc.h"
#include "calcMainWindow.h"

int main(int argc, char *argv[]) {

    QApplication a(argc, argv);

    // Create main window
    CalcMainWindow mainWindow;

    // Create UI
    Ui::MainWindow calc;
    calc.setupUi(&mainWindow);
    mainWindow.init(calc.lineEdit,
                    calc.label_Cache);
    //mainWindow.init(calc.lineEdit, nullptr);
    //mainWindow.init(nullptr, calc.label_Cache);

    // Show form
    mainWindow.show();

    return QApplication::exec();

}
