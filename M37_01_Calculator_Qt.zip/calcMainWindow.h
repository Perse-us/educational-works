//
// Created by Perseus on 25.03.2023.
//

#ifndef M37_01_CALCULATOR_QT_CALCMAINWINDOW_H
#define M37_01_CALCULATOR_QT_CALCMAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QLabel>

class CalcMainWindow : public QMainWindow {

    Q_OBJECT

    enum MathOperations {
        none = -1, add, sub, mlt, dvd
    };

    static std::string getOperationSign(MathOperations operation) {
        if (operation == add) return "+";
        else if (operation == sub) return "-";
        else if (operation == mlt) return "\303\227";
        else if (operation == dvd) return "\303\267";
        else return "";
    }

    // Fields of form
    QLineEdit* lineEdit = nullptr;
    QLabel* label_Cache = nullptr;

    // Init constants
    const int zero = 0;
    const int valSize = 12;
    const char signSym = '-';
    const char dotSym = '.';
    const char zeroSym = '0';
    const QString zeroText = QString(zeroSym);

    // Working variables
    bool isInit = false;
    MathOperations currOperation = none;
    bool isEnter = false;
    bool wrongState = false;
    double cacheVal = zero;

    void clearCache() {
        if (isInit) {
            cacheVal = zero;
            currOperation = none;
            label_Cache->clear();
        }
    }

    void setWrongState(const char* text) {
        if (isInit) {
            lineEdit->setText(text);
            wrongState = true;
        }
    }

    void setZero() {
        if (isInit) {
            lineEdit->setText(zeroText);
            isEnter = false;
            wrongState = false;
        }
    }

    bool isZero() const {
        return !isInit || lineEdit->text() == zeroText;
    }

    // Used throw!!!
    QString getTextByVal(double val) const {

        QString text;
        int base = 10;

        // Calculate size of integer part
        auto calcIntPartSize = [this, base] (double valIn) {
            int size = zero;
            auto val = (long long) valIn;
            while (val != zero) {
                size++;
                val /= base;
            }
            if (size == zero) size++;
            return size;
        };

        // Value text forming
        text.setNum(val, (char) base, valSize - calcIntPartSize(val));
        while (!text.isEmpty()) {
            QCharRef lastChar = text.back();
            if ((text.contains(dotSym) && lastChar == zeroSym)
                || lastChar == dotSym
                || lastChar == signSym) {
                text.remove(text.size() - 1, 1);
            }
            else break;
        }
        if (text.isEmpty()) text = zeroText;

        // Check size
        if (calcIntPartSize(text.toDouble()) > valSize)
            throw std::invalid_argument("Too huge result!");

        return text;

    }

    double getEnteredValue() const {

        double result = zero;

        if (isInit) {
            bool ok;
            result = lineEdit->text().toDouble(&ok);
            if (!ok) result = zero;
        }

        return result;

    }

    void addDigit(const char sign) {
        if (isInit) {
            // Getting to next value
            if (!isEnter || wrongState) setZero();
            // Enter curr value
            QString text = lineEdit->text();
            // Check dot
            bool isDot = sign == dotSym;
            bool hasDot = text.contains(dotSym);
            if (!isDot || !hasDot ) {
                // Check max value size
                int maxSize = valSize;
                if (text.contains(signSym)) maxSize++;
                if (hasDot) maxSize++;
                if (text.size() < maxSize) {
                    // Zero string correction
                    if (isZero() && !isDot) text.clear();
                    // Add digit
                    lineEdit->setText(text + sign);
                    isEnter = true;
                }
            }
        }
    }

    // Forming result from cached & current values
    void formResult() {
        if (isInit) {
            if (currOperation != none) {
                double result = zero, currVal = getEnteredValue();
                try {
                    // Get result
                    if (currOperation == add) result = cacheVal + currVal;
                    else if (currOperation == sub) result = cacheVal - currVal;
                    else if (currOperation == mlt) result = cacheVal * currVal;
                    else if (currOperation == dvd) {
                        if (currVal == zero) throw std::invalid_argument(
                                    "Division by zero is not allowed!");
                        result = cacheVal / currVal;
                    } else throw std::invalid_argument("Wrong operation!");
                    // Out correct result
                    lineEdit->setText(getTextByVal(result));
                } catch (const std::invalid_argument& err) {
                    // Out wrong result
                    setWrongState(err.what());
                }
                clearCache();
            }
            isEnter = false;
        }
    }

    void operate(MathOperations operation) {
        if (isInit) {
            // Check valid
            if (operation == none || wrongState) return;
            // Get previous result
            if (isEnter) formResult();
            if (!wrongState) {
                if (currOperation == none) cacheVal = getEnteredValue();
                currOperation = operation;
                try {
                    label_Cache->setText(getTextByVal(cacheVal).append(
                            getOperationSign(operation).c_str()));
                } catch (const std::invalid_argument& err) {
                    setWrongState(err.what());
                    clearCache();
                }
            }
        }
    }

public:
    CalcMainWindow() = default;
    CalcMainWindow(QWidget* parent) : QMainWindow(parent) {}

    void init(QLineEdit* lineEditIn, QLabel* label_CacheIn) {
        lineEdit = lineEditIn;
        label_Cache = label_CacheIn;
        isInit = lineEdit != nullptr && label_Cache != nullptr;
        setZero();
    }

public slots:
    // Add digits, sign & dot
    void add0() { addDigit(zeroSym); };
    void add1() { addDigit('1'); };
    void add2() { addDigit('2'); };
    void add3() { addDigit('3'); };
    void add4() { addDigit('4'); };
    void add5() { addDigit('5'); };
    void add6() { addDigit('6'); };
    void add7() { addDigit('7'); };
    void add8() { addDigit('8'); };
    void add9() { addDigit('9'); };
    void dot() { addDigit(dotSym); };
    void sign() {
        if (isInit) {
            if (!wrongState && !isZero()) {
                isEnter = true;
                QString text = lineEdit->text();
                if (text.contains(signSym)) text.remove(signSym);
                else text.insert(zero, signSym);
                lineEdit->setText(text);
            }
        }
    };

    // Calculate
    void result() { formResult(); };
    void plus() { operate(add); };
    void minus() { operate(sub); };
    void mult() { operate(mlt); };
    void div() { operate(dvd); };

    // Clear
    void clearEnter() { setZero(); };
    void clearAll() {
        clearCache();
        clearEnter();
    };

};

#endif //M37_01_CALCULATOR_QT_CALCMAINWINDOW_H
