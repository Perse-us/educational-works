#include <QApplication>
#include <QVBoxLayout>
#include <QLabel>
#include <QSlider>
#include <QPushButton>
// Graphic effects
#include <QGraphicsScene>
#include <QGraphicsBlurEffect>
#include <QGraphicsPixmapItem>
#include <QPainter>
// File works
#include <QFileDialog>

#include <iostream>

class BlurLabel : public QLabel {
    Q_OBJECT

public:
    BlurLabel(QWidget* parent = nullptr) : QLabel(parent) {}

    virtual void paintEvent(QPaintEvent* e) override {

        if (origin == nullptr) return;

        // Get blur image
        QGraphicsScene scene;
        QGraphicsPixmapItem item;
        item.setPixmap(*origin);
        auto* blur = new QGraphicsBlurEffect;
        blur->setBlurRadius(currBlur);
        item.setGraphicsEffect(blur);
        scene.addItem(&item);

        // Paint result
        QPainter paint(this);
        QSize newSize((int) scene.width(), (int) scene.height());
        newSize.scale(width(), height(), Qt::KeepAspectRatio);
        QRect rect((width() - newSize.width()) / 2,
                   (height() - newSize.height()) / 2,
                   newSize.width(), newSize.height());
        scene.render(&paint, rect,
                     QRectF(0, 0,
                            scene.width(), scene.height()));

    }

public slots:
    void loadPicture(QString& fileName) {
        if (!fileName.isEmpty())
            origin = std::make_unique<QPixmap>(fileName);
    }

    void blurImg(int blurRad) {
        currBlur = blurRad / blurRat;
        if (currBlur < 0) currBlur = 0;
        else if (currBlur > 100) currBlur = 100;
        repaint();
    }

private:
    const int blurRat = 4;
    int currBlur = 0;
    std::unique_ptr<QPixmap> origin = nullptr;

};

int main(int argc, char *argv[]) {

    QApplication a(argc, argv);

    // GUI
    QWidget window;
    window.setWindowTitle("Blur image");
    window.setMinimumSize(600, 350);
    QVBoxLayout box(&window);
    //
    auto picLabel = new BlurLabel(&window);
    picLabel->setAlignment(Qt::AlignCenter);
    picLabel->setToolTip("Current picture");
    box.addWidget(picLabel);
    auto blurSlider = new QSlider(Qt::Horizontal, &window);
    blurSlider->setToolTip("Change blur effect");
    box.addWidget(blurSlider);
    auto openButton = new QPushButton("Open", &window);
    openButton->setToolTip("Open picture");
    box.addWidget(openButton);

    // Algorithms
    QObject::connect(openButton, &QPushButton::clicked,
                     [picLabel] () {
        QString fileName = QFileDialog::getOpenFileName(nullptr,
                                                 "Select picture...",
                                                 "../mm",
                                                 "Picture files (*.jpg; *.jpeg; *.png)");
        picLabel->loadPicture(fileName);
    });
    QObject::connect(blurSlider, &QSlider::valueChanged,
                     picLabel, &BlurLabel::blurImg);

    // Progress app
    window.show();
    return QApplication::exec();

}

#include <main.moc>
