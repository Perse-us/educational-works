#include <iostream>
#include <fstream>
#include <map>
#include "nlohmann/json.hpp"

// Interface class
class Interface {

public:

    static const int sizeOfSplitter = 40;

    static void outSplitter (char sign = '-') {

        std::string splitter;
        splitter.assign(sizeOfSplitter, sign);
        std::cout << splitter << std::endl;

    }

    static void outHeader(const char* headerText) {

        outSplitter('=');
        std::cout << headerText << std::endl;
        outSplitter('=');

    }

    // Stream block
    static void refreshInStream() {
        std::cin.clear();
        std::cin.seekg(0);
    }

};

// Tag, actor name
std::map<std::string, std::map<std::string, bool>> actors;
// Actor name, film name, role name(s)
std::map<std::string, std::map<std::string, std::map<std::string, bool>>> roles;

void createBase(nlohmann::json& dataSet) {

    // Create move info
    //nlohmann::json dataSet;
    // 1
    dataSet["The Master and Margarita"] = {
            {"Country", "Russia"},
            {"Year", 1994},
            {"Production", "TAMP"},
            {"Writer", "Yuri Kara"},
            {"Director", "Yuri Kara"},
            {"Producer", "Vladimir Skoriy"}
    };
    dataSet["The Master and Margarita"]["Actors"] = {
            {"Margarita", "Anastasiya Vertinskaya"},
            {"The Master", "Viktor Rakov"},
            {"Woland", "Valentin Gaft"},
            {"Ivan Bezdomny", "Sergey Garmash"},
            {"Pontius Pilate", "Mikhail Ulyanov"},
            {"Korovyev", "Aleksandr Filippenko"},
            {"Behemoth", "Viktor Pavlov"},
            {"Yeshua Ha-Nozri", "Nikolai Burlyayev"},
            {"Kaifa", "Vyacheslav Shalevich"},
            {"Azazello", "Vladimir Steklov"}
    };
    // 2
    dataSet["The 10th Kingdom"] = {
            {"Country", "United States"},
            {"Year", 2000},
            {"Production", "Carnival Films"},
            {"Writer", "Simon Moore"},
            {"Director", "David Carson, Herbert Wise"},
            {"Producer", "Robert Halmi Sr., Robert Halmi Jr., Simon Moore"}
    };
    dataSet["The 10th Kingdom"]["Actors"] = {
            {"Virginia Lewis", "Kimberly Williams"},
            {"Anthony \"Tony\" Lewis", "John Larroquette"},
            {"Wolf", "Scott Cohen"},
            {"Christine White (Evil Queen)", "Dianne Wiest"},
            {"Prince Wendell", "Daniel Lapaine"},
            {"The Huntsman", "Rutger Hauer"},
            {"Relish, the Troll King", "Ed O'Neill"}
    };
    // 3
    dataSet["Frozen"] = {
            {"Country", "United States"},
            {"Year", 1000},
            {"Production", "Walt Disney Animation Studios"},
            {"Writer", "Chris Buck, Jennifer Lee, Shane Morris"},
            {"Director", "Chris Buck, Jennifer Lee"},
            {"Producer", "Peter Del Vecho"}
    };
    dataSet["Frozen"]["Actors"] = {
            {"Anna", "Kristen Bell"},
            {"Elsa", "Idina Menzel"},
            {"Kristoff", "Jonathan Groff"},
            {"Olaf", "Josh Gad"},
            {"Hans", "Santino Fontana"}
    };
    // 4
    dataSet["The Sixth Sense"] = {
            {"Country", "United States"},
            {"Year", 1999},
            {"Production", "Spyglass Entertainment, Hollywood Pictures"},
            {"Writer", "M. Night Shyamalan"},
            {"Director", "M. Night Shyamalan"},
            {"Producer", "Frank Marshall, Kathleen Kennedy, Barry Mendel"}
    };
    dataSet["The Sixth Sense"]["Actors"] = {
            {"Malcolm Crowe", "Bruce Willis"},
            {"Cole Sear", "Haley Joel Osment"},
            {"Lynn Sear", "Toni Collette"},
            {"Anna Crowe", "Olivia Williams"},
            {"Vincent Grey", "Donnie Wahlberg"},
            {"Sean", "Glenn Fitzgerald"},
            {"Kyra Collins", "Mischa Barton"},
            {"Tommy Tammisimo", "Trevor Morgan"},
            {"Mr. Stanley Cunningham", "Bruce Norris"},
            {"Mrs. Collins", "Angelica Page"}
    };
    // 5
    dataSet["Avatar"] = {
            {"Country", "United States, United Kingdom"},
            {"Year", 2009},
            {"Production", "20th Century Fox"},
            {"Writer", "James Cameron"},
            {"Director", "James Cameron"},
            {"Producer", "James Cameron"}
    };
    dataSet["Avatar"]["Actors"] = {
            {"Jake Sully", "Sam Worthington"},
            {"Neytiri te Tskaha Mo'at'ite", "Zoe Saldana"},
            {"Miles Quaritch", "Stephen Lang"},
            {"Trudy Chacon", "Michelle Rodriguez"},
            {"Parker Selfridge", "Giovanni Ribisi"},
            {"Dr. Norm Spellman", "Joel David Moore"}
    };

}

void addActorsTags(const std::string& actorName) {

    std::string currTag;
    actors[actorName][actorName] = false; // Add full name tag
    for (int i = 0; i < actorName.length(); ++i) {

        const char& currChar = actorName[i];

        if (currChar != ' ') currTag.append(1, currChar);
        if ((currChar == ' ' || i == actorName.length() - 1)
            && !currTag.empty()) {
                actors[currTag][actorName] = false; // Add part of name tag
                currTag.clear();
        }

    }

}

void readData(const nlohmann::json& dataSet) {

    // Iteration by iterator
    std::cout << "Roles list:\n";
    Interface::outSplitter();
    for (auto data_It = dataSet.begin();
        data_It != dataSet.end(); ++data_It) {

        // Get film name
        const std::string& filmName = data_It.key();
        std::cout << "\"" << filmName << "\" actors:\n";

        // Get actors and roles
        nlohmann::json actorsSet = data_It.value()["Actors"];
        // Iteration by for(auto)
        for (auto& role : actorsSet.items()) {

            std::cout << "- " << role.value() << " as \""
                << role.key() << "\"\n";
            // Add actor's tags (once)
            if (roles.find(role.value()) == roles.end())
                addActorsTags(role.value());
            // Add role
            roles[role.value()][filmName][role.key()] = false;

        }

        Interface::outSplitter();

    }

}

void outActorStarred(const std::string& findName) {

    const auto tag_It = actors.find(findName);

    if (tag_It == actors.end())
        std::cout << "Actor by \"" << findName << "\" isn't found!\n";

    else {

        for (const auto& actorByTag : tag_It->second) {
            const auto actor_it = roles.find(actorByTag.first);
            std::cout << "Actor \"" << actor_it->first << "\" starred:\n";
            if (actor_it != roles.end()) {
                for (const auto& film : actor_it->second)
                    for (const auto& role : film.second)
                        std::cout << "- At \"" << film.first << "\" as \""
                            << role.first << "\"\n";

            }

        }

    }

}

int main() {

    // Initialization
    const char* stopWord = "#stop";
    nlohmann::json dataSet;

    Interface::outHeader("JSON move catalog");

    createBase(dataSet);
    std::cout << "JSON data set:\n";
    Interface::outSplitter();
    std::cout << dataSet.dump(2) << std::endl;
    Interface::outSplitter();

    readData(dataSet);

    while(true) {

        std::string userInput;
        std::cout << "Enter actors part or full name (" << stopWord << " - for finish" << "):\n";
        std::getline(std::cin, userInput);

        if (userInput == stopWord) break;
        else outActorStarred(userInput);
        Interface::outSplitter();

    }

    return 0;

}
