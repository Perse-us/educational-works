//
// Created by Perseus on 27.03.2023.
//

#ifndef M37_02_TV_RC_TV_RC_H
#define M37_02_TV_RC_TV_RC_H

#include <QMainWindow>
#include <QLabel>
#include <QTimer>

class TvRcMainWindow : public QMainWindow {
    Q_OBJECT

public:
    TvRcMainWindow() = default;
    TvRcMainWindow(QWidget* parent) : QMainWindow(parent) { }

    void init(QLabel* labelIn) {
        label = labelIn;
        isInit = label != nullptr;
        outState();
    }

public slots:
    // Volume slots
    void volUpPress() {
        if (timer->isActive()) return;
        connect(timer, &QTimer::timeout,
                [this] () {
                    changeVol(stepUp * volStep);
                    triggeringTimer();
                });
        startTimer();
    };
    void volUpRelease() { releaseTimer(); };
    void volDwnPress() {
        if (timer->isActive()) return;
        connect(timer, &QTimer::timeout,
                [this] () {
                    changeVol(stepDown * volStep);
                    triggeringTimer();
                });
        startTimer();
    };
    void volDwnRelease() { releaseTimer(); };

    // Channels slots
    void ch0() { setChannel(0); };
    void ch1() { setChannel(1); };
    void ch2() { setChannel(2); };
    void ch3() { setChannel(3); };
    void ch4() { setChannel(4); };
    void ch5() { setChannel(5); };
    void ch6() { setChannel(6); };
    void ch7() { setChannel(7); };
    void ch8() { setChannel(8); };
    void ch9() { setChannel(9); };
    void chUpPress() {
        if (timer->isActive()) return;
        connect(timer, &QTimer::timeout,
                [this] () {
                    changeChannel(stepUp);
                    triggeringTimer();
        });
        startTimer();
    };
    void chUpRelease() { releaseTimer(); };
    void chDwnPress() {
        if (timer->isActive()) return;
        connect(timer, &QTimer::timeout,
                [this] () {
                    changeChannel(stepDown);
                    triggeringTimer();
                });
        startTimer();
    };
    void chDwnRelease() { releaseTimer(); };

private:

    enum ChangeStep { stepDown = -1, stepUp = 1 };

    // Parent objects
    QLabel* label = nullptr;
    QTimer* timer = new QTimer;

    // State constants
    const int volStep = 10;
    const int volMin = 0;
    const int volMax = 10 * volStep;
    const int chanMin = 0;
    const int chanMax = 9;

    // Working variable
    bool isInit = false;
    int volCurr = (volMax - volMin) / 2 / volStep * volStep;
    int chanCurr = chanMin;

    // Work with timer
    bool timerCharged = false;
    void startTimer() {
        if (timer->isActive()) return;
        timer->setSingleShot(false);
        timer->start(700);
        timerCharged = true;
    }
    void releaseTimer() {
        timer->setSingleShot(true);
        if (timerCharged) timer->setInterval(0);
        else triggeringTimer();
    }
    void triggeringTimer() {
        timerCharged = false;
        if (timer->isSingleShot()) {
            timer->stop();
            timer->disconnect();
        }
    }

    void outState () {
        if (!isInit) return;
        label->setText("Ch: " + QString(std::to_string(chanCurr).c_str()) + '\n'
                       + "Vol: " + QString(std::to_string(volCurr).c_str()) + '%');
    };

    void changeVol(int change) {
        if (!change) return;
        volCurr += change;
        if (volCurr < volMin) volCurr = volMin;
        if (volCurr > volMax) volCurr = volMax;
        outState();
    }

    void setChannel(int channel) {
        if (chanCurr == channel) return;
        chanCurr = channel;
        outState();
    }

    void changeChannel(int change) {
        if (!change) return;
        int chanNew = chanCurr + change;
        int chanCount = chanMax - chanMin + 1;
        if (chanCount != 0) {
            // Channel correction
            while (chanNew > chanMax) chanNew -= chanCount;
            while (chanNew < chanMin) chanNew += chanCount;
        }
        setChannel(chanNew);
    }

};

#endif //M37_02_TV_RC_TV_RC_H
