#include <QApplication>
#include "ui_tv_rc.h"
#include "tv_rc.h"

int main(int argc, char *argv[]) {

    QApplication a(argc, argv);

    TvRcMainWindow mainWindow;
    Ui::MainWindow init;
    init.setupUi(&mainWindow);
    mainWindow.init(init.label);

    mainWindow.show();

    return QApplication::exec();

}
