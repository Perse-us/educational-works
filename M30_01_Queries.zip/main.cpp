#include <iostream>
#include <cpr/cpr.h>

// Interface class
class Interface {

public:

    static const int sizeOfSplitter = 40;

    static void outSplitter (char sign = '-') {

        std::string splitter;
        splitter.assign(sizeOfSplitter, sign);
        std::cout << splitter << std::endl;

    }

    static void outHeader(const char* headerText) {

        outSplitter('=');
        std::cout << headerText << std::endl;
        outSplitter('=');

    }

    // Stream block
    static void refreshInStream() {
        std::cin.clear();
        std::cin.seekg(0);
    }

};

// User commands class
class UserCmd {

public:

    enum CmdList{
        non = -1, get, post, put, del, patch, fin
    };

private:

    struct userCmdWrite{
        const char* name;
        const char* description;
    };

    static constexpr userCmdWrite userCmdList[(int) fin + 1] {
            "get", "Get query",
            "post", "Post query",
            "put", "Put query",
            "delete", "Delete query",
            "patch", "Patch query",
            "exit", "Finish work"
    };

public:

    static void outUserCmdList() {

        std::cout << "Available commands:\n";
        const userCmdWrite* cmd_Pnt = userCmdList - 1;
        while (++cmd_Pnt < std::end(userCmdList))
            std::cout << " - \"" << cmd_Pnt->name << "\" - "
                      << cmd_Pnt->description << std::endl;

    }

    static CmdList getCmdByName(const std::string& cmdName) {

        const userCmdWrite* cmd_Pnt = userCmdList - 1;
        while (++cmd_Pnt < std::end(userCmdList))
            if (cmd_Pnt->name == cmdName) return (CmdList) (cmd_Pnt - userCmdList);

        return UserCmd::non;

    }

};

int main() {

    Interface::outHeader("HTTP-Queries");

    // Initialization
    const char* baseUrl = "http://httpbin.org/";

    // List of command
    UserCmd::outUserCmdList();
    Interface::outSplitter();

    // User interface
    while (true) {

        std::string usrIn;
        std::cout << "Enter command:\n";
        std::getline(std::cin, usrIn);
        Interface::outSplitter();

        // Commands
        UserCmd::CmdList usrCmd = UserCmd::getCmdByName(usrIn);
        if (usrCmd == UserCmd::fin) break;
        else if (usrCmd == UserCmd::get)
            std::cout << "Result \"" << usrIn << "\" query:\n"
                << cpr::Get(cpr::Url(
                        (std::string) baseUrl + "get")).text
                << std::endl;
        else if (usrCmd == UserCmd::post)
            std::cout << "Result \"" << usrIn << "\" query:\n"
                << cpr::Post(cpr::Url(
                        (std::string) baseUrl + "post")).text
                << std::endl;
        else if (usrCmd == UserCmd::put)
            std::cout << "Result \"" << usrIn << "\" query:\n"
                << cpr::Put(cpr::Url(
                        (std::string) baseUrl + "put")).text
                << std::endl;
        else if (usrCmd == UserCmd::del)
            std::cout << "Result \"" << usrIn << "\" query:\n"
                << cpr::Delete(cpr::Url(
                        (std::string) baseUrl + "delete")).text
                << std::endl;
        else if (usrCmd == UserCmd::patch)
            std::cout << "Result \"" << usrIn << "\" query:\n"
                << cpr::Patch(cpr::Url(
                        (std::string) baseUrl + "patch")).text
                << std::endl;
        else {
            std::cout << "Wrong command!\n";
            Interface::outSplitter();
            UserCmd::outUserCmdList();
        }
        Interface::outSplitter();

    }

    std::cout << "Finish work\n";

    return 0;

}
