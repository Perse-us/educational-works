//
// The project uses a media file: "Good Night (Vladivostok)"
// With no intended commercial purpose
// The author has not been clarified unequivocally
//
#include <QApplication>
#include <QPushButton>
#include <QPainter>
#include <QPaintEvent>
#include <QMediaPlayer>

const std::string dirMediaPath = "../mm";
const std::string redBtnPath = dirMediaPath + "/p_red.png";
const std::string greenBtnPath = dirMediaPath + "/p_green.png";
const std::string audioPath = dirMediaPath + "/GoodNight.mp3";

class ImgButton : public QPushButton {
    Q_OBJECT

public:
    // Constructors
    ImgButton(QWidget *parent = nullptr) {

        // Parent
        setParent(parent);

        // Load pictures
        mBtnStop = QPixmap(greenBtnPath.c_str());
        mBtnPlay = QPixmap(redBtnPath.c_str());

        // Tune media
        player = new QMediaPlayer(this);
        player->setMedia(QUrl(audioPath.c_str()));
        player->setVolume(60);
        connect(player, &QMediaPlayer::mediaStatusChanged,
                [this] (QMediaPlayer::MediaStatus currState) {
            if (currState == QMediaPlayer::EndOfMedia)
                changeState();
        });

        // Preset
        setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        setGeometry(mBtnStop.rect());
        mySize = geometry().size();

        // Click connection
        connect(this, &QPushButton::clicked,
                this, &ImgButton::changeState);

    }

    // Paint event
    void paintEvent(QPaintEvent *e) override {
        QPainter paint(this);
        setToolTip(isPlaing ? "Push for stop..." : "Push me...");
        paint.drawPixmap(e->rect(), (isPlaing ? mBtnStop : mBtnPlay));
    }

    // Size hint
    QSize sizeHint() const override { return mySize; }
    QSize minimumSizeHint() const override { return sizeHint(); }

public slots:
    void changeState() {
        if (!isPlaing) {
            player->setPosition(1000);
            //player->setPosition(180000);
            player->play();
        } else {
            player->stop();
        }
        isPlaing = !isPlaing;
        update();
    }

private:
    QSize mySize; // Button size
    bool isPlaing = false;
    //QPixmap mCurrBtn; // Current view
    QPixmap mBtnPlay; // Down view
    QPixmap mBtnStop; // Up view
    QMediaPlayer* player = nullptr; // Player

};

int main(int argc, char *argv[]) {

    QApplication a(argc, argv);

    ImgButton imgBtn(nullptr);
    imgBtn.setWindowTitle("Audio button");
    imgBtn.setFixedSize(imgBtn.minimumSizeHint());
    imgBtn.move(200, 200);
    imgBtn.show();

    return QApplication::exec();

}

#include "main.moc"
