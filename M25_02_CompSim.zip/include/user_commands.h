#pragma once
#include <iostream>

// User commands block
enum class userCmd{
    non = -1, input, display, sum, save, load, help, exit
};
struct userCmdWrite{
    std::string name;
    std::string description;
};
userCmdWrite userCmdList[(int) userCmd::exit + 1] {
        "input", "Enter data",
        "display", "Out data",
        "sum", "Sum of entered data",
        "save", "Save data",
        "load", "Load saved data",
        "help", "Out commands list",
        "exit", "Finish work"
};

void outUserCmdList() {

    std::cout << "Available commands:\n";
    const userCmdWrite* cmd_Pnt = std::begin(userCmdList) - 1;
    while (++cmd_Pnt < std::end(userCmdList))
        std::cout << " - \"" << cmd_Pnt->name << "\" - "
        << cmd_Pnt->description << std::endl;

}

userCmd getCmdByName(const std::string& cmdName) {

    const userCmdWrite* cmd_Pnt = std::begin(userCmdList) - 1;
    while (++cmd_Pnt < std::end(userCmdList))
        if (cmd_Pnt->name == cmdName) return (userCmd) (cmd_Pnt - std::begin(userCmdList));

    return userCmd::non;

}