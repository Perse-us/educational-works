// Version 1.0
#pragma once
#include <iostream>

// Splitter block
int sizeOfSplitter = 30;
void outSplitter (char sign = '-') {

    std::string splitter;
    splitter.assign(sizeOfSplitter, sign);
    std::cout << splitter << std::endl;

}

void outHeader(const char* headerText) {

    outSplitter('=');
    std::cout << headerText << std::endl;
    outSplitter('=');

}

// Stream block
void refreshInStream() {
    std::cin.clear();
    std::cin.seekg(0);
}
