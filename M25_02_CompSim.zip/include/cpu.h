#pragma once
#include "ram.h"
#include <iostream>

void compute();
