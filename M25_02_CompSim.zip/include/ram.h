#pragma once
#include <vector>

int getRamSize();

std::vector<int> read();

void write(std::vector<int>& ramIn);