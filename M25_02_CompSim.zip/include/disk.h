#pragma once
#include "ram.h"
#include <iostream>
#include <fstream>

void save();

void load();