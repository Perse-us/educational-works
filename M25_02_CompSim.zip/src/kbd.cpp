#include "kbd.h"

void input() {

    std::vector<int> data(getRamSize());

    // Enter data
    std::vector<int>::iterator data_Pnt = --data.begin();
    std::cout << "Enter " << data.size() << " integer values:\n";
    while (++data_Pnt < data.end()) {

        while (true) {

            // Get value
            std::cin >> *data_Pnt;

            // Check value
            if (!std::cin.fail()) break;
            std::cin.clear();
            std::cin.seekg(0);
            std::cerr << "Wrong entered value! Repeat please...\n";

            auto enteredValues = data_Pnt - data.begin();
            if (data_Pnt > data.begin())
                std::cout << "Entered values: " << enteredValues
                    << (enteredValues > 0 ? "\n(last: " + std::to_string(*(data_Pnt - 1)) + ")" : "")
                    << std::endl;

        }

    }

    write(data);

}
