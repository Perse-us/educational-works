#include "disk.h"

std::string fileName = "data.txt";

void save() {

    std::ofstream file(fileName);

    if (file.is_open()) {

        // Get data from RAM
        const std::vector<int> data = read();

        // Save data to file
        std::vector<int>::const_iterator data_Pnt = --data.cbegin();
        while (++data_Pnt < data.cend()) {
            if (file.tellp() != 0) file << std::endl;
            file << *data_Pnt;
        }

        file.close();

        std::cout << "Data successfully saved\n";

    } else std::cerr << "No access to the file!\n";


}

void load() {

    std::ifstream file(fileName);

    if (file.is_open()) {

        // Get data from file
        std::vector<int> data;
        while (!file.eof()) {

            int currData;
            file >> currData;
            data.push_back(currData);

        }

        // Write data to RAM
        write(data);

        file.close();

        std::cout << "Data successfully loaded\n";

    } else std::cerr << "Saved file \"" << fileName
        << "\" is not found!\n";

}