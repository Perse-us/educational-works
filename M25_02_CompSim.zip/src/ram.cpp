#include "ram.h"

const int ramSize = 8;
int ram[ramSize];

void ramWork(std::vector<int>& outData, bool isRead) {

    int* ram_Pos = std::begin(ram);
    std::vector<int>::iterator outData_Pos = outData.begin();

    while (ram_Pos < std::end(ram)) {

        if (isRead) *outData_Pos = *ram_Pos;
        else *ram_Pos = *outData_Pos;

        outData_Pos++;
        ram_Pos++;

    }

}

int getRamSize() {
    return ramSize;
}

std::vector<int> read() {

    std::vector<int> ramOut(ramSize);

    ramWork(ramOut, true);

    return ramOut;

}

void write(std::vector<int>& ramIn) {

    ramWork(ramIn, false);

}