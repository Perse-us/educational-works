#include "cpu.h"

void compute() {

    int result = 0;
    std::vector<int> ramData = read();

    std::vector<int>::const_iterator ramData_Pnt = ramData.cbegin();
    while(ramData_Pnt < ramData.cend())
        result += *ramData_Pnt++;

    std::cout << "Total sum of entered data: " << result << std::endl;

}