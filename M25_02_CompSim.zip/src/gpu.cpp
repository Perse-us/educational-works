#include "gpu.h"

void display() {

    // Get data
    const std::vector<int> ramData = read();

    // Out data
    int cellIndex = 0;
    std::vector<int>::const_iterator ramData_Pnt
        = ramData.cbegin();
    std::cout << "Entered data:\n";
    while (ramData_Pnt < ramData.cend()) {
        std::cout.width(3);
        std::cout << cellIndex++ << ") " << *ramData_Pnt++ << std::endl;
    }

}
