#include "v_comm.h"
#include "user_commands.h"
#include "kbd.h"
#include "gpu.h"
#include "cpu.h"
#include "disk.h"

int main() {

    outHeader("Computer simulator");

    // Command list
    outUserCmdList();
    outSplitter();

    while (true) {

        std::string userInput;

        // Get command
        refreshInStream();
        std::cout << "Enter command:\n";
        std::getline(std::cin, userInput);
        userCmd currCmd = getCmdByName(userInput);
        outSplitter();

        // Select and use command
        if (currCmd == userCmd::exit) break;
        else if (currCmd == userCmd::help) outUserCmdList();
        else if (currCmd == userCmd::input) input();
        else if (currCmd == userCmd::display) display();
        else if (currCmd == userCmd::sum) compute();
        else if (currCmd == userCmd::save) save();
        else if (currCmd == userCmd::load) load();
        else {
            // Wrong command
            std::cout << "Wrong command!\n";
            outSplitter();
            outUserCmdList();
        }

        outSplitter();

    }

    std::cout << "Finish work\n";

    return 0;

}
